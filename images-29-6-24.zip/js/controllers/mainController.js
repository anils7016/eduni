app.controller('MainController', ['$scope', 'DataService', function($scope, DataService) {
    // Controller logic here
    $scope.message = 'Hello from MainController!';
    $scope.isHomePage = true;
    
  }]);
  