angular.module('myApp')
  .controller('AboutController', function($scope) {
    // Controller logic here
    $scope.isHomePage = false;

  });
