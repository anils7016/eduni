app.service('DataService', function() {
    // Service logic here
  });
  